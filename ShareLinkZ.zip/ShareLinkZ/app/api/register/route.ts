import { NextResponse } from 'next/server'
import { connectToDatabase } from '@/lib/mongodb'
import { hash } from 'bcrypt'

export async function POST(req: Request) {
  try {
    const { username, email, password } = await req.json()
    const { db } = await connectToDatabase()

    // Check if user already exists
    const existingUser = await db.collection('users').findOne({ $or: [{ username }, { email }] })
    if (existingUser) {
      return NextResponse.json({ error: 'User already exists' }, { status: 400 })
    }

    // Hash password
    const hashedPassword = await hash(password, 10)

    // Create new user
    const result = await db.collection('users').insertOne({
      username,
      email,
      password: hashedPassword
    })

    return NextResponse.json({ message: 'User created successfully', userId: result.insertedId }, { status: 201 })
  } catch (error) {
    console.error('Registration error:', error)
    return NextResponse.json({ error: 'Internal Server Error' }, { status: 500 })
  }
}

