import { NextResponse } from 'next/server'
import { connectToDatabase } from '@/lib/mongodb'
import { getServerSession } from 'next-auth/next'
import { authOptions } from '../../../auth/[...nextauth]/route'
import { ObjectId } from 'mongodb'

export async function POST(req: Request, { params }: { params: { boardId: string } }) {
  try {
    const session = await getServerSession(authOptions)
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { url, description, deadline } = await req.json()
    const { db } = await connectToDatabase()

    const result = await db.collection('boards').findOneAndUpdate(
      { _id: new ObjectId(params.boardId), userId: session.user.id },
      { $push: { links: { _id: new ObjectId(), url, description, deadline, visited: false } } },
      { returnDocument: 'after' }
    )

    if (!result.value) {
      return NextResponse.json({ error: 'Board not found' }, { status: 404 })
    }

    return NextResponse.json(result.value)
  } catch (error) {
    console.error('Error adding link:', error)
    return NextResponse.json({ error: 'Internal Server Error' }, { status: 500 })
  }
}

