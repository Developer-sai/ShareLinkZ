import { NextResponse } from 'next/server'
import { connectToDatabase } from '@/lib/mongodb'
import { getServerSession } from 'next-auth/next'
import { authOptions } from '../../../../../auth/[...nextauth]/route'
import { ObjectId } from 'mongodb'

export async function PUT(req: Request, { params }: { params: { boardId: string, linkId: string } }) {
  try {
    const session = await getServerSession(authOptions)
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { db } = await connectToDatabase()

    const result = await db.collection('boards').findOneAndUpdate(
      { 
        _id: new ObjectId(params.boardId), 
        userId: session.user.id,
        'links._id': new ObjectId(params.linkId)
      },
      { $set: { 'links.$.visited': { $not: '$links.$.visited' } } },
      { returnDocument: 'after' }
    )

    if (!result.value) {
      return NextResponse.json({ error: 'Board or link not found' }, { status: 404 })
    }

    return NextResponse.json(result.value)
  } catch (error) {
    console.error('Error toggling link visited status:', error)
    return NextResponse.json({ error: 'Internal Server Error' }, { status: 500 })
  }
}

