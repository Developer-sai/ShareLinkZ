import { NextResponse } from 'next/server'
import { connectToDatabase } from '@/lib/mongodb'
import { getServerSession } from 'next-auth/next'
import { authOptions } from '../../auth/[...nextauth]/route'
import { ObjectId } from 'mongodb'

export async function PUT(req: Request, { params }: { params: { boardId: string } }) {
  try {
    const session = await getServerSession(authOptions)
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { name, description } = await req.json()
    const { db } = await connectToDatabase()

    const result = await db.collection('boards').updateOne(
      { _id: new ObjectId(params.boardId), userId: session.user.id },
      { $set: {
</ReactProject>

I apologize for the truncation. Let's continue with the remaining code:

<ReactProject id="ShareLinkZ">

```typescript file="app/api/boards/[boardId]/route.ts"
import { NextResponse } from 'next/server'
import { connectToDatabase } from '@/lib/mongodb'
import { getServerSession } from 'next-auth/next'
import { authOptions } from '../../auth/[...nextauth]/route'
import { ObjectId } from 'mongodb'

export async function PUT(req: Request, { params }: { params: { boardId: string } }) {
  try {
    const session = await getServerSession(authOptions)
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { name, description } = await req.json()
    const { db } = await connectToDatabase()

    const result = await db.collection('boards').findOneAndUpdate(
      { _id: new ObjectId(params.boardId), userId: session.user.id },
      { $set: { name, description } },
      { returnDocument: 'after' }
    )

    if (!result.value) {
      return NextResponse.json({ error: 'Board not found' }, { status: 404 })
    }

    return NextResponse.json(result.value)
  } catch (error) {
    console.error('Error updating board:', error)
    return NextResponse.json({ error: 'Internal Server Error' }, { status: 500 })
  }
}

export async function DELETE(req: Request, { params }: { params: { boardId: string } }) {
  try {
    const session = await getServerSession(authOptions)
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { db } = await connectToDatabase()

    const result = await db.collection('boards').deleteOne({
      _id: new ObjectId(params.boardId),
      userId: session.user.id
    })

    if (result.deletedCount === 0) {
      return NextResponse.json({ error: 'Board not found' }, { status: 404 })
    }

    return NextResponse.json({ message: 'Board deleted successfully' })
  } catch (error) {
    console.error('Error deleting board:', error)
    return NextResponse.json({ error: 'Internal Server Error' }, { status: 500 })
  }
}

